#Nombre completo
# cédula 7965465465
# Grupo No 6

peso=float(input("Por favor digite su peso ejemplo 80.5: "))
estatura=float(input("Por favor digite su peso ejemplo 1.85: "))
imc = peso/estatura**2
print("El indice de masa corporal es: ",imc)
if(imc < 18.5):
    print("Estas en bajo peso")
    inscripción = 100000
    inscripción = inscripción - inscripción *0.10
    print("se ha realizado un descuento del 10% para un valor de inscripcción de : ", inscripción)
if(imc >= 18.5 and imc <= 24.9):
    print("Estas en peso normal")
if(imc >= 25 and imc <= 29.9):
    print("Estas en sobrepeso")
if(imc >= 30):
    print("Estas en Obesidad")

